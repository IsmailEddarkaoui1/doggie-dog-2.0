﻿using System;

namespace PEI
{
    class Program
    {
        static void Main(string[] args)
        {
            KattenWeetjesService kattenWeetjesService = new KattenWeetjesService();
            kattenWeetjesService.KattenWeetjesVullen();
            Console.WriteLine(kattenWeetjesService.KattenWeetjeRandom());
        }
    }
}
