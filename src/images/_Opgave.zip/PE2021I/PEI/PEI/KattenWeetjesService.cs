﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PEI
{
    public class KattenWeetjesService
    {
        public void KattenWeetjesVullen()
        {
            KattenWeetjeApiService kattenWeetjeApiService = new KattenWeetjeApiService();

            KattenWeetjesInMemoryDb.kattenWeetjes.Clear();
            for (int i = 0; i < 10; i++)
            {
                KattenWeetjesInMemoryDb.kattenWeetjes.Add(kattenWeetjeApiService.KattenWeetje());
            }
        }
        public string KattenWeetjeRandom()
        {
            Random random = new Random();
            return KattenWeetjesInMemoryDb.kattenWeetjes[random.Next(10)].fact;
        }
    }
}
