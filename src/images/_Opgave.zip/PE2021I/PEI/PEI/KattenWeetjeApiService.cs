﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace PEI
{
    public class KattenWeetjeApiService
    {
        public KattenWeetjeResponse  KattenWeetje()
        {
            string url = "https://catfact.ninja/fact";

            using (var httpClient = new HttpClient())
            {
                var httpRespone = httpClient.GetAsync(url).GetAwaiter().GetResult();
                var response = httpRespone.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                return JsonConvert.DeserializeObject<KattenWeetjeResponse>(response);
            }
        }
    }
}
